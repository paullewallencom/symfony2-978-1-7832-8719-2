<?php

namespace Khepin\BookBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class KhepinBookBundle extends Bundle
{
}
