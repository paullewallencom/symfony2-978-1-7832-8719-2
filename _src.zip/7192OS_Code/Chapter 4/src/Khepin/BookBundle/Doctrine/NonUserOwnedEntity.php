<?php

namespace Khepin\BookBundle\Doctrine;

interface NonUserOwnedEntity
{

}